package com.d.gngry;

import java.util.ArrayList;

public interface AdapterCallback {

    void onMethodCallback(int position, ArrayList<ForecastModel> forecastList);
}
